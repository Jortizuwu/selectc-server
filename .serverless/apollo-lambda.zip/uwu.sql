	


    'Derecho'
    'Administracion en Finanzas y Negocios Internacionales'
    'Ingeniería Ambiental'
    'Ingeniería de Sistemas'
    'Ingeniería Industrial'
    'Ingeniería Mecánica'
    'Ingeniería Agronómica'
    'Ingeniería de Alimentos'
    'Medicina Veterinaria y Zootecnia' sindatos
    'Bacteriologia'
    'Enfermería'
    'Tecnologia en Regencia y Farmacia'
    'Administración en Salud'
    'Estadistica' sindatos
    'Matemáticas'
    'Geografía'
    'Física'
    'Química'
    'Biología'
    'Licenciatura en Educacion Artistica'
    'Licenciatura en Ciencias Sociales'
    'Licenciatura Educacion Fisica, Recreacio y Deporte'
    'Licenciatura en Literatura y Lengua Castellana'
    'Licenciatura en informática'
    'Licenciatura en Lengua Extrangera con Enfasis en Ingles'
    'Licenciatura en Ciencias Naturales y Educacion Ambiental'
    'Licenciatura en educación infantil'
    'Acuicultura' sindatos
