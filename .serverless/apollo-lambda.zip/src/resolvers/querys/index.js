const userQuerys = require('./user')
const roleQuerys = require('./role')
const careerQuerys = require('./career')
const schoolQuerys = require('./school')

module.exports = { userQuerys, roleQuerys, careerQuerys, schoolQuerys }
